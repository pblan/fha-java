
public class Test {

	public static void main(String[] args) {
			Schiebepuzzle puzzle = new Schiebepuzzle();
			// Mischen nicht vergessen, ansonsten hat der Spieler sehr schnell gewonnen
			
			puzzle.mische();
			System.out.println(puzzle.toString());
			// Testen des Loesungsalgorithmus
			// -> zufaellig schieben
			Loesungsalgorithmus alg1 = new SchiebAlg1();
			//Loesungsalgorithmus alg1 = new SchiebAlg1();
			int nrSteps=alg1.loese(puzzle);
			System.out.println(puzzle.toString());
			System.out.println("Gelöst mit "+nrSteps+" Schritten");
		
	}

}
