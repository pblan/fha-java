
public class WrongMoveException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public WrongMoveException(String s) {
		super(s);
	}
}
