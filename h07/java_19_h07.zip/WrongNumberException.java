
public class WrongNumberException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public WrongNumberException(String s) {
		super(s);
	}
}
