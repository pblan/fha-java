package homework;

/**
 * Ein Interface, welches die Struktur fuer Rechenoperationen mit/ueber/auf doubles festlegt.
 * 
 * @author Patrick Blaneck, Felix Racz, Tim Wende
 * @version 1.1
 */
public interface Rechenoperation {
	public double berechne(double x);
}
